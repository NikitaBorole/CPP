#include<iostream>
using namespace std;
int main()
{
int i;
cout<<"This is a output\n\n";
cout<<"enter a number";
cin>>i;
cout << i << "square is"<< i*i << "\n";
return 0;
}
 
