#include<iostream>
using namespace std;
int main()
{
int n1,n2;
cout<<"enter first number";
cin>>n1;
cout<<"enter second number";
cin>>n2;
try
{
if(n2!=n1)
{
float div=(float)n1/n2;
if(div<0)
throw 'e';
cout<<"n1/n2="<<div;
}
else
throw n2;
}
catch(int e)
{
cout<<"Exception: dividion by zero";
}
catch (char st)
{
cout<<"Exception: dividion is less than 1";
}
catch(...)
{
cout<<"Exception: unkonwn";
}
return 0;
}

