#include<iostream>
#include<fstream>
using namespace std;
int main()
{
fstream fin;
fin.open("data.txt");
int count=0;
char word[30];
if(!fin)
{
cout<<"file did not open";
}
else
{
while(fin>>word)
count++;
}
cout<<"total word:"<<count<<endl;
fin.close();
}
