#include<iostream>
#include<exception>
using namespace std;
class divided
{
private:
int *x;
int *y;
public:
divided()
{
x=new int();
y=new int();
cout<<"enter two number:";
cin>>*x>>*y;
try
{
if(*y==0)
{
throw *x;
}
}
catch(int)
{
delete x; delete y;
cout<<"second number can not be zero!"<<endl;
throw;
}
}
~divided()
{
try
{
delete x; delete y;
}
catch(...)
{
cout<<"Error while deallocating memory"<<endl;
}
float division()
{
return(float)*x / *y;
}
};


int main()
{
try
{
divided d;
float res = d.division();
cout<<"result of dividion is:"<<endl;
}
catch(...)
{
cout<<"unknown exception!"<<endl;
}
return 0;
}
}
