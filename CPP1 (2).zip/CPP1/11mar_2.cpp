#include<iostream>
using namespace std;
/*int main()
{
int number ,ans;
number = 10;
ans=number/0;
cout<<"result:"<<ans<<end;*/

try
{
if(n2==0)
throw n2;
else
{
result = n1/n2;
cout<<"\n The results is:"<<result;
}
}
catch(int x)
{
cout<<"\ncant divided by :"<<x;
}
cout<<"\nend of program";
}
