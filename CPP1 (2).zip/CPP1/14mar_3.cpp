#include<iostream>
#include<exception>
using namespace std;
class Myexception : public exception
{
public:
const char * what() const throw()
{
return "Attempted to divided by zero!\n";
}
};
 
int main()
{
try
{
int x,y;
cout<<"Enter the two number\n";
cin>>x>>y;
if(y==0)
{
Myexception z;
throw z;
}
else
cout<<"x/y="<<x/y<<endl;
}

catch(exception& e)
{
cout<< e.what();
}
return 0;
}


