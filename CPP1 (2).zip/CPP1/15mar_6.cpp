//write

#include<iostream>
#include<fstream>
using namespace std;
class student
{
int roll;
char name[25];
float marks;
void getdata()
{
cout<<"enter roll no and name"<<endl;
cin>>roll>>name;
cout<<"marks"<<endl;
cin>>marks;

}

public:
void display()
{
fstream f;
student s;
f.open("student.dat",ios::in|ios::binary);
f.read((char*) &s,sizeof(s));
cout<<"roll "<<s.roll<<endl<<"Name "<<s.name<<endl<<"marks "<<s.marks<<endl;
f.close();
}

public:
void addrecord()
{
fstream f;
student stu;
f.open("student.dat",ios::app|ios::binary);
stu.getdata();
f.write((char*)&stu,sizeof(stu));
f.close();
}
};//end of class

int main()
{
student s;
char ch='n';
char buff;
do
{
s.addrecord();
cout<<"want add more?(y/n)"<<endl;
cin>>buff;
ch=getchar();
}
while(ch =='y' || ch =='Y');
cout<<"updated!!"<<endl;
s.display();
}//end main


