#include<iostream>
using namespace std;
int main()
{
int a=1;
try
{
try
{
throw a;
}
catch(int x)
{
cout<<"\nexception in inner try catch block"<<endl;
throw x;
}
}
catch(int n)
{
cout<<"\nException in outer try catch block"<<endl;
}
cout<<"\nend of program"<<endl;
}
