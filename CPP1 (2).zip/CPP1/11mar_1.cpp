#include<iostream>
using namespace std;
class A
{
public:
	int a;
	void display()
	{
		cout<<"Inside A";
	}
};

class B : public A
{
public:
	int b;
	void show()
	{
	cout<<"Inside B";
	}
};
class C;
{
public:
	int c;
	void print()
	{
	cout<<"Inside C";
	}
};
class D;
{
public:
	int d;
	void print()
	{
	cout<<"Inside D";
	}
};
class E : public C, public D
{
public:
void sum()
{
cout<<"inside E and sum:"<<c+d;
}
};
class F;
{
public:
	int f;
	void print()
	{
	cout<<"Inside F";
	}
};

int main()
{
E s;
s.c=5;
s.d=2;
e.sum();
a.displayA();
b.displayA();
b.displayC();
b.displayD();


f.displayA();
f.displayC();
f.displayB();
f.displayE();


}
