#include<iostream>
using namespace std;
class base
{
protected:
int i;
public:
bese1(int x)
{
i=x;
cout<<"constructing base1";
}
~base1();
{
cout<<"destructing base\n";
};

class base2
{
protected:
int k;
public:
base2(int x)
{
k=x;
cout<<"constructing base2\n";
}
~base2()
{
 cout<<"distructing base1\n";
}
};
class derived: public base1,public base2
{
int j;
public:
derived(int x,int y,int z):base1(y),base2(z)
{
j=x;
cout<<"constructing derived\n";
}
void show()
{
cout<<i<<" "<<j<<" "<<k;
}
};

int main()
{
derived ob(3,4,5);
ob.show();
return 0;
}
}
