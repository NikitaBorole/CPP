//Hybrid homework


#include<iostream>
using namespace std;
class A
{
public:
	int a;
	void display()
	{
		cout<<"Inside A";
	}
};

class B : public A
{
public:
	int b;
	void show()
	{
	cout<<"inside B";
	}
};
class C;
{
public:
	int c;
	void print()
	{
	cout<<"Inside C";
	}
};
class D : public B, public C
{
public:
void sum()
{
cout<<"inside D and sum:"<<b+c;
}
};

int main()
{
D s;
s.b=5;
s.c=2;
d.sum();
}
