#include<iostream>
using namespace std;
class complex 
{
int r,i;
public:
complex()
{
r=i=0;
}
complex(int x, int y)
{
r=x;
i=y;
}
void display()
{
cout<<"\nreal="<<r<<endl;
cout<<"\nimg="<<i<<endl;
}
int operator==(complex);
};


int complex::operator ==(complex c)
{
if(r==c.r && i==c.i)
return 1;
else
return 0;
}
