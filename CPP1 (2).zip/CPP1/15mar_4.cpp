#include<iostream>
#include<fstream>
using namespace std;
int main()
{
fstream fin;
fin.open("data.txt");
int count=0;
string str;
if(!fin)
{
cout<<"file did not open";
}
else
{
while(getline(fin,str))
count++;
}
cout<<"total line:"<<count<<endl;
fin.close();
}
