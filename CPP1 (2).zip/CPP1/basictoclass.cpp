//Basic type to class type convergen constructor
//goal: convert basic type into time type.
//input integer -120 this is a number of minits
//int m-120,time t1=m;-----> t1.hour =2, t1.min =6;


#include<iostream>
using namespace std;

class time
{
int hour,min;
public:
time(){cout<<"default\n";
hour =0;
min=0;
}
time(int x){//param constructor
cout<<"param constructor\n";
hour= x / 60;
min =x % 60;

}
void display()
{
cout<<"Time is:"<<hour<<"and min"<<min<<"min"<<endl;
}

};


int main()
{
int j = 96;
time t1;
t1=j;
//j=t1;
t1.display();
return 0;
}
