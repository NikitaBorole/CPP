#include<iostream>
using namespace std;
class shape
{
protected:
float x;
public:
void getdata()
{
cin>>x;
}
virtual float calculatearea()=0;
};

class square : public shape
{
public:
float calculatearea()
{
return x*x;
}
};


class circle : public shape
{
public:
float calculatearea()
{
return 3.14*x*x;
}
};

int main()
{
square s;
circle c;
cout<<"enter the lenght of calculate area of square: ";
s.getdata();
cout<<"\narea of square: \n"<<s.calculatearea();
cout<<"\nenter the radius of circle: ";
c.getdata();
cout<<"\narea of circle: "<<" "<<c.calculatearea()<<endl;
}

