#include<iostream>
using namespace std;
class base
{
int x;
public:
base()
{
cout<<"Base default constructor";
}
};

class derived : public base
{
int y;
public :
derived()
{
cout<<"derived default constructor";
derived(int i)
cout<<"derived parameterised constructor";
}
};


int main()
{
base b;
derived d1;
derived d2(10);
}
